export interface agentData{
    agentId?: Number,
    agentName: String,
    agentPassword: String
}