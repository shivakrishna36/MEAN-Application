import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.css']
})
export class CustomerHomeComponent implements OnInit {

  currentUserId: Number;
  balance: String;
  username: String;
  constructor(private router: Router, private appService: AppService) { }

  ngOnInit() {
    this.currentUserId = +sessionStorage.getItem('currentId');
    if(!this.currentUserId){
      this.router.navigate(['/customerLogin']);
    }
    this.username = sessionStorage.getItem('username');

  }

  getBalance() {
    this.appService.getBalance(this.currentUserId).subscribe((data) => {
      console.log("datastfjh", data);
      this.balance = `your account balance is` + data.amount;
    })

  }

  logout() {
    sessionStorage.clear();
    this.router.navigate(['/customerLogin']);
  }

}
