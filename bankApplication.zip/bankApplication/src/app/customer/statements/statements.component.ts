import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-statements',
  templateUrl: './statements.component.html',
  styleUrls: ['./statements.component.css']
})
export class StatementsComponent implements OnInit {

  currentUserId: Number;
  statements: any;
  constructor(private router: Router, private appService: AppService) { }

  ngOnInit() {
    this.currentUserId = +sessionStorage.getItem('currentId');
    if (!this.currentUserId) {
      this.router.navigate(['/customerLogin']);
    }
    else {
      this.appService.getStatements(this.currentUserId).subscribe((data) => {
        console.log(data);
        this.statements = data;
      })
    }
  }



  logout() {
    sessionStorage.clear();
    this.router.navigate(['/customerLogin']);
  }

}
