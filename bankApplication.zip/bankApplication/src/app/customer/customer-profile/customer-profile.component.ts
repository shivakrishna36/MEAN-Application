import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit {

  currentUserId: Number;
  customerObject: any;

  constructor(private app: AppService, private router: Router) { }

  ngOnInit() {
    this.currentUserId = +sessionStorage.getItem('currentId');
    if (!this.currentUserId) {
      this.router.navigate(['/customerLogin']);
    }
    else {
      this.app.getAccountDetailsById(this.currentUserId).subscribe((data) => {
        this.customerObject = data;
      })
    }
  }

}
