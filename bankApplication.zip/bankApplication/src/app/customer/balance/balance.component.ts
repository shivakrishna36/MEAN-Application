import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.css']
})
export class BalanceComponent implements OnInit {

  currentUserId: Number;
  balance: Number;
  constructor(private router: Router, private appService: AppService) { }

  ngOnInit() {
    this.currentUserId = +sessionStorage.getItem('currentId');
    if (!this.currentUserId) {
      this.router.navigate(['/']);
    }
    else {
      this.appService.getBalance(this.currentUserId).subscribe((data) => {
        console.log("datastfjh", data);
        this.balance = data.amount;
      })
    }

  }

  logout() {
    sessionStorage.clear();
    this.router.navigate(['/customerLogin']);
  }

}
