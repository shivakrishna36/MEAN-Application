import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-customer-transactions',
  templateUrl: './customer-transactions.component.html',
  styleUrls: ['./customer-transactions.component.css']
})
export class CustomerTransactionsComponent implements OnInit {

  currentUserId: Number;
  message: String;
  result: String;
  transactionObject: object;
  constructor(private router:Router,private appService:AppService) { }

  ngOnInit() {
    this.currentUserId = +sessionStorage.getItem('currentId');
    if(!this.currentUserId){
      this.router.navigate(['/customerLogin']);
    }
  }


  createTransaction(object){
    console.log("cust trans",object);

    if(object.accountNumber == this.currentUserId){
      this.message = "You can't send money to same account";
      this.router.navigate(['/customerTransactions']);
    }

    else{
      this.appService.getAccountDetailsById(object.accountNumber).subscribe((data)=>{
        console.log("data",data);
        if(!data){
          this.message = 'invalid account number';
          this.router.navigate(['/customerTransactions']);
        }
        else{
          this.appService.getAccountDetailsById(this.currentUserId).subscribe((data)=>{
       
            if(object.amount > data.amount){
              this.message = 'insufficient Amount';
              this.router.navigate(['/customerTransactions']);
            }
            else {
              this.appService.getMobileBankingAccount(this.currentUserId).subscribe((data)=>{
                if(object.password != data.password){
                  this.message = 'Please check your password';
                }
                else{
                  this.transactionObject = {
                    senderAccountNumber: this.currentUserId,
                    receiverAccountNumber: object.accountNumber,
                    amount: object.amount,
                    type: 'debit'
                  }
                  this.message = '';
                  this.appService.createCustomerTransaction(this.transactionObject).subscribe((data)=>{
                    this.result = 'Transaction Success';
                    setTimeout(() => {
                      this.router.navigate(['/customerHome']);
                    }, 1000);
                    
                  })
                }
              })
            }
          })
        }
      })
    }

    // this.appService.getAccountDetailsById(object.accountNumber).subscribe((data)=>{
    //   console.log("data",data);
    //   if(!data){
    //     this.message = 'invalid account number';
    //     this.router.navigate(['/customerTransactions']);
    //   }
    //   else{
    //     this.appService.getAccountDetailsById(this.currentUserId).subscribe((data)=>{
     
    //       if(object.amount > data.amount){
    //         this.message = 'insufficient Amount';
    //         this.router.navigate(['/customerTransactions']);
    //       }
    //       else {
    //         this.appService.getMobileBankingAccount(this.currentUserId).subscribe((data)=>{
    //           if(object.password != data.password){
    //             this.message = 'Please check your password';
    //           }
    //           else{
    //             this.transactionObject = {
    //               senderAccountNumber: this.currentUserId,
    //               receiverAccountNumber: object.accountNumber,
    //               amount: object.amount,
    //               type: 'debit'
    //             }
    //             this.message = '';
    //             this.appService.createCustomerTransaction(this.transactionObject).subscribe((data)=>{
    //               this.result = 'Transaction Success';
    //               setTimeout(() => {
    //                 this.router.navigate(['/customerHome']);
    //               }, 1000);
                  
    //             })
    //           }
    //         })
    //       }
    //     })
    //   }
    // })

    // this.appService.getAccountDetailsById(this.currentUserId).subscribe((data)=>{
     
    //   if(object.amount > data.amount){
    //     this.message = 'insufficient Amount';
    //     this.router.navigate(['/customerTransactions']);
    //   }
    //   else {
    //     this.appService.getMobileBankingAccount(this.currentUserId).subscribe((data)=>{
    //       if(object.password != data.password){
    //         this.message = 'Please check your password';
    //       }
    //       else{
    //         this.transactionObject = {
    //           senderAccountNumber: this.currentUserId,
    //           receiverAccountNumber: object.accountNumber,
    //           amount: object.amount,
    //           type: 'debit'
    //         }
    //         this.message = '';
    //         this.appService.createCustomerTransaction(this.transactionObject).subscribe((data)=>{
    //           this.result = 'Transaction Success';
    //           setTimeout(() => {
    //             this.router.navigate(['/customerHome']);
    //           }, 1000);
              
    //         })
    //       }
    //     })
    //   }
    // })
  }


  logout(){
    sessionStorage.clear();
    this.router.navigate(['/customerLogin']);
  }
}
