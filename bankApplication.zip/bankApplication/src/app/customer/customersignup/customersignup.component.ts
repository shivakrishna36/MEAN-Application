import { Component, OnInit, ViewChild } from '@angular/core';

import { AppService } from '../../app.service';

import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { customerData } from './customer.model';

@Component({
  selector: 'app-customersignup',
  templateUrl: './customersignup.component.html',
  styleUrls: ['./customersignup.component.css']
})
export class CustomersignupComponent implements OnInit {

  @ViewChild('loginForm',null) loginForm:NgForm;

  customer: customerData;
  constructor(private appService:AppService,private router:Router) { }

  ngOnInit() {
    this.customer = {
      firstName: '',
    lastName: '',
    accountNumber: null,
    password: ''
    }
  }

  customerSignup(obj){
    console.log("custObj",obj);

    this.appService.customerSignup(obj).subscribe((data)=>{
      console.log("custagent data",data);
      this.router.navigate(['/customerLogin']);

    })


  }

}
