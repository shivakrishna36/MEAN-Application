export class customerData{
    firstName: String;
    lastName: String;
    accountNumber: Number;
    password: String;
}