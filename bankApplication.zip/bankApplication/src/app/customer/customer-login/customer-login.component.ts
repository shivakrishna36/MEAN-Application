import { Component, OnInit } from '@angular/core';
import { observable } from 'rxjs';
import { AppService } from '../../app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {
  currentUserId: Number;
  balance: String;
  agentId: Number;
  message: String;

  constructor(private appService: AppService, private router: Router) { }

  ngOnInit() {
    this.currentUserId = +sessionStorage.getItem('currentId');
    if (this.currentUserId) {
      this.router.navigate(['/customerHome']);
    }
    this.agentId = +sessionStorage.getItem('agentId');
    if (this.agentId) {
      this.router.navigate(['/agentHome']);
    }
  }

  customerLogin(object) {
    console.log("object", object);
    this.appService.customerLogin(object.loginId).subscribe((data) => {
      console.log("data", data);
      if(data == null){
      this.message = "invalid credentials";
      }else{
      if (object.password == data.password) {
        sessionStorage.setItem('currentId', object.loginId);
        sessionStorage.setItem('username',(data.firstName.toString()));
        this.currentUserId = object.loginId;
        this.router.navigate(['/customerHome'])
      }
      else{
        this.message = "invalid password";
      }
    }
    })
  }

}
