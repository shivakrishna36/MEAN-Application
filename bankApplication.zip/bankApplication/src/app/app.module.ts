import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms'
import { HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { AgentLoginComponent } from './agent/agent-login/agent-login.component';
import { CustomerLoginComponent } from './customer/customer-login/customer-login.component';
import { HomeComponent } from './home/home.component';
import { AgentsignupComponent } from './agent/agentsignup/agentsignup.component';
import { CustomersignupComponent } from './customer/customersignup/customersignup.component';
import { AppService } from './app.service';
import { AccountDetailsComponent } from './agent/account-details/account-details.component';
import { AgentHomeComponent } from './agent/agent-home/agent-home.component';
import { CustomerNewAccountComponent } from './agent/customer-new-account/customer-new-account.component';
import { TransactionComponent } from './agent/transaction/transaction.component';
import { TransactionConfirmComponent } from './agent/transaction-confirm/transaction-confirm.component';
import { ShowTransactionsComponent } from './agent/show-transactions/show-transactions.component';
import { DemandDraftComponent } from './agent/demand-draft/demand-draft.component';
import { DemandDraftconfirmComponent } from './agent/demand-draftconfirm/demand-draftconfirm.component';
import { CustomerHomeComponent } from './customer/customer-home/customer-home.component';
import { CustomerTransactionsComponent } from './customer/customer-transactions/customer-transactions.component';
import { StatementsComponent } from './customer/statements/statements.component';
import { BalanceComponent } from './customer/balance/balance.component';
import { LogoutComponent } from './agent/logout/logout.component';
import { CustomerProfileComponent } from './customer/customer-profile/customer-profile.component';



const routes: Routes = [
  { path: 'agentLogin', component: AgentLoginComponent },
  { path: 'agentSignup', component: AgentsignupComponent},
  { path: 'agentHome', component: AgentHomeComponent},
  { path: 'customerSignupByAgent', component: CustomerNewAccountComponent},
  { path: 'accountDetails', component: AccountDetailsComponent},
  { path: 'transaction', component: TransactionComponent},
  { path: 'transactionConfirm', component: TransactionConfirmComponent},
  { path: 'showTransactions', component: ShowTransactionsComponent},
  { path: 'dd', component: DemandDraftComponent},
  { path: 'ddConfirm', component: DemandDraftconfirmComponent},
  { path: 'agentLogout', component: LogoutComponent},
  
  { path: 'customerLogin', component: CustomerLoginComponent },
  { path: 'customerSignup', component: CustomersignupComponent},
  { path: 'customerHome', component: CustomerHomeComponent},
  { path: 'customerTransactions', component: CustomerTransactionsComponent},
  { path: 'statements', component: StatementsComponent},
  { path: 'getBalance', component: BalanceComponent},
  { path: 'getProfile', component: CustomerProfileComponent},
  { path: '**', component: HomeComponent },
  { path: '', redirectTo: '**', pathMatch: 'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    AgentLoginComponent,
    CustomerLoginComponent,
    HomeComponent,
    AgentsignupComponent,
    CustomersignupComponent,
    AccountDetailsComponent,
    AgentHomeComponent,
    CustomerNewAccountComponent,
    TransactionComponent,
    TransactionConfirmComponent,
    ShowTransactionsComponent,
    DemandDraftComponent,
    DemandDraftconfirmComponent,
    CustomerHomeComponent,
    CustomerTransactionsComponent,
    StatementsComponent,
    BalanceComponent,
    LogoutComponent,
    CustomerProfileComponent
  ],
  imports: [
    FormsModule,
    RouterModule.forRoot(routes),
    BrowserModule,
    HttpClientModule
  ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
