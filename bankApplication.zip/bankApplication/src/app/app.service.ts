import { Injectable } from '@angular/core'
import { Observable, observable } from 'rxjs'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { agentData } from './app.model'
import { customerData } from './customer/customersignup/customer.model';
import { customerAccountData } from './agent/customer-new-account/customerAcc';


@Injectable()
export class AppService {

    headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    constructor(private httpClient: HttpClient) { }

    agentSignup(data: agentData): Observable<String> {
        return this.httpClient.post<String>('http://localhost:4444/agentSignup', data, { headers: this.headers })
    }


    agentLogin(id: Number): Observable<agentData> {
        return this.httpClient.get<agentData>(`http://localhost:4444/agentLogin/${id}`, { headers: this.headers });
    }


    customerSignupByAgent(object: customerAccountData): Observable<String> {
        return this.httpClient.post<String>('http://localhost:4444/customerSignupByAgent', object, { headers: this.headers });
    }


    customerSignup(data: customerData): Observable<String> {
        console.log("inside service cust signup", data);
        return this.httpClient.post<String>('http://localhost:4444/customerAccountSignup', data, { headers: this.headers })
    }


    customerLogin(id: Number): Observable<customerData> {
        return this.httpClient.get<customerData>(`http://localhost:4444/customerLogin/${id}`, { headers: this.headers });
    }


    getAccountDetails(): Observable<customerAccountData[]> {
        return this.httpClient.get<customerAccountData[]>('http://localhost:4444/accountDetails', { headers: this.headers });
    }


    getBalance(id): Observable<any> {
        return this.httpClient.get<any>(`http://localhost:4444/getBalance/${id}`);
    }


    getAccountDetailsById(id): Observable<any> {
        return this.httpClient.get<any>(`http://localhost:4444/accountDetails/${id}`);
    }


    updateAccountBalance(object): Observable<any> {
        return this.httpClient.post<any>('http://localhost:4444/update', object, { headers: this.headers });
    }


    getTransactions(): Observable<any> {
        return this.httpClient.get<any>('http://localhost:4444/getTransactions', { headers: this.headers });
    }


    getTransactionsById(id): Observable<any> {
        return this.httpClient.get<any>(`http://localhost:4444/getTransactions/${id}`, { headers: this.headers });
    }


    createDD(object): Observable<any> {
        return this.httpClient.post<any>('http://localhost:4444/dd', object, { headers: this.headers });
    }


    getDD(): Observable<any> {
        return this.httpClient.get<any>('http://localhost:4444/dd', { headers: this.headers });
    }


    getMobileBankingAccount(id): Observable<any> {
        return this.httpClient.get<any>(`http://localhost:4444/accountById/${id}`, { headers: this.headers });
    }


    createCustomerTransaction(object): Observable<any> {
        return this.httpClient.post<any>('http://localhost:4444/customerTransaction', object, { headers: this.headers });
    }


    getStatements(id): Observable<any> {
        return this.httpClient.get<any>(`http://localhost:4444/getStatements/${id}`, { headers: this.headers });
    }


}