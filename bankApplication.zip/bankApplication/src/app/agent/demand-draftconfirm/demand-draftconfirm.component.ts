import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-demand-draftconfirm',
  templateUrl: './demand-draftconfirm.component.html',
  styleUrls: ['./demand-draftconfirm.component.css']
})
export class DemandDraftconfirmComponent implements OnInit {

  dd: Object;
  date = new Date();
  agentId: Number;
  constructor(private router:Router,private appService:AppService) { }

  ngOnInit() {
    this.agentId = +sessionStorage.getItem('agentId');
    if(!this.agentId){
      this.router.navigate(['/agentlogin']);
    }
    this.appService.getDD().subscribe((data)=>{
      this.dd = data[0];
    })
  }


  logout(){
    sessionStorage.clear();
    this.router.navigate(['/agentLogin']);
  }

}
