import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-new-account',
  templateUrl: './customer-new-account.component.html',
  styleUrls: ['./customer-new-account.component.css']
})
export class CustomerNewAccountComponent implements OnInit {

  agentId:Number;

  constructor(private appService:AppService, private router:Router) { }

  ngOnInit() {
    this.agentId = +sessionStorage.getItem('agentId');
    if(!this.agentId){
      this.router.navigate(['/agentLogin']);
    }
  }

  customerSignupByAgent(object){
    console.log("custByagent data",object);
    this.appService.customerSignupByAgent(object).subscribe((data)=>{
      console.log("data",data);
      this.router.navigate(['/agentHome']);
    })


  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['/agentLogin']);
  }

}
