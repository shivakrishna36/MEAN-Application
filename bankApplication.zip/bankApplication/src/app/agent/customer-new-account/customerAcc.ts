export interface customerAccountData{
accountNumber?: Number,
 firstName: String,
 lastName: String,
 fatherName: String,
 motherName: String,
 age: Number,
 gender: String,
 mobileNumber: Number,
 amount: Number,
 address: String,
 dateOfBirth: Date,
 type: String
}