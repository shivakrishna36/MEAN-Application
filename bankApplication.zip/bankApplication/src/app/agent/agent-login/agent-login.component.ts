import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';
import { Router } from '@angular/router';
import { customerAccountData } from '../customer-new-account/customerAcc';
@Component({
  selector: 'app-agent-login',
  templateUrl: './agent-login.component.html',
  styleUrls: ['./agent-login.component.css']
})
export class AgentLoginComponent implements OnInit {

  agentId: Number;
  message: String;
  currentUserId: Number;
  accounts: customerAccountData[];
  constructor(private appService: AppService, private router: Router) { }

  ngOnInit() {
    this.agentId = +sessionStorage.getItem('agentId');
    if (this.agentId) {
      this.router.navigate(['/agentHome']);
    }
    this.currentUserId = +sessionStorage.getItem('currentId');
    if (this.currentUserId) {
      this.router.navigate(['/customerHome']);
    }
  }

  agentLogin(object) {
    this.appService.agentLogin(object.loginId).subscribe((data) => {
      if (data == null)
        this.message = "please enter valid details"
      else {
        if (object.password == data.agentPassword) {
          sessionStorage.setItem('agentId', object.loginId);
          this.message = '';

          this.router.navigate(['/agentHome'])
        }
        else{
          this.message = "invalid password"

        }

      }
    })


  }

  // accountDetails() {
  //   this.appService.getAccountDetails().subscribe((data) => {
  //     console.log("Account Detais", data);
  //     this.accounts = data;
  //   })
  // }



}
