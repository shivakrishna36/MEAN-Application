import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-transactions',
  templateUrl: './show-transactions.component.html',
  styleUrls: ['./show-transactions.component.css']
})
export class ShowTransactionsComponent implements OnInit {

  agentId: Number;
  show:boolean = false;
  allTransactions: [];
  constructor(private appService:AppService, private router: Router) { }

  ngOnInit() {
    this.agentId = +sessionStorage.getItem('agentId');
    if(!this.agentId){
      this.router.navigate(['/agentLogin']);
    }
   
  }

showAllTransactions(){
  this.show = true;
  this.appService.getTransactions().subscribe((data)=>{
    console.log("transactions",data);
    this.allTransactions = data;
  })
}

  showTransactions(object){
    this.show = true;
    this.allTransactions = [];
    console.log("object",object);
   this.appService.getTransactionsById(object.search).subscribe((data)=>{
     console.log(data);
     this.allTransactions = data;

   })
  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['/agentLogin']);
  }

}
