import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-transaction-confirm',
  templateUrl: './transaction-confirm.component.html',
  styleUrls: ['./transaction-confirm.component.css']
})
export class TransactionConfirmComponent implements OnInit {

  agentId: Number;
  customerObject: any;
  transactionObject: any;
  message: String;
  updateObject: any;
  constructor(private appService: AppService, private router: Router) { }

  ngOnInit() {
    this.agentId = +sessionStorage.getItem('agentId');
    if (!this.agentId) {
      this.router.navigate(['/agentLogin']);
    }
    this.message = 'Confirm details to continue';
    this.customerObject = JSON.parse(sessionStorage.getItem('customerObject'));
    this.transactionObject = JSON.parse(sessionStorage.getItem('transactionObject'));
  }

  transactionConfirm() {

    
      this.updateObject = {
        accountNumber: this.customerObject.accountNumber,
        type: this.transactionObject.type,
        amount: this.transactionObject.amount
      }
      console.log("updateObject", this.updateObject);
      this.appService.updateAccountBalance(this.updateObject).subscribe((data) => {
        console.log("transaction successful");
      })
      this.router.navigate(['/agentHome'])
  }

  logout() {
    sessionStorage.clear();
    this.router.navigate(['/agentLogin']);
  }
}
