import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { Router } from '@angular/router';
import { disableDebugTools } from '@angular/platform-browser';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  agentId: Number;
  customerObject: any;
  message: String;

  constructor(private appService: AppService, private router: Router) { }

  ngOnInit() {
    this.agentId = +sessionStorage.getItem('agentId');
    if (!this.agentId) {
      this.router.navigate(['/agentLogin']);
    }
  }

  searchAccount(object) {
    console.log("object", object);
    this.appService.getAccountDetailsById(object.search).subscribe((data) => {
      console.log("accountByid data", data);
      if(!data){
        this.message = "Account not found"
      }
      this.customerObject = data;
    })

  }

  makeTransaction(object) {
    console.log("transaction type",object);
    if(this.customerObject.amount < object.amount && object.type == 'debit'){
      this.message = 'Insufficient Amount'
    }else{
    sessionStorage.setItem('customerObject',JSON.stringify(this.customerObject));
    sessionStorage.setItem('transactionObject',JSON.stringify(object));
    this.router.navigate(['/transactionConfirm']);
    }
  }

  logout() {
    sessionStorage.clear();
    this.router.navigate(['/agentLogin']);
  }

}
