import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';
import { customerAccountData } from '../customer-new-account/customerAcc';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  show: boolean = false;
  agentId: Number;
  accounts: customerAccountData[];
  message: String;

  constructor(private appService:AppService, private router:Router) { }

  ngOnInit() {
    this.agentId = +sessionStorage.getItem('agentId');
    if(!this.agentId){
      this.router.navigate(['/agentLogin']);
    }
  }

  getAccountDetail(object){
    this.show = true;
    console.log(object);
    this.accounts = [];
    this.appService.getAccountDetailsById(object.search).subscribe((data)=>{
     
      if(!data){
        this.message = 'Account not found';
      }
      else{
        this.message = '';
        this.accounts.push(data);
      }
    })
  }

  showAll(){
    this.show = true;
    
    this.appService.getAccountDetails().subscribe((data)=>{
      console.log("Account Detais",data);
      this.message = '';
      this.accounts = data;
      
    })
  }
 
  logout(){
    sessionStorage.clear();
    this.router.navigate(['/agentLogin']);
  }
 

}
