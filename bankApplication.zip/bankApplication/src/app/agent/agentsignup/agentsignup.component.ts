import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-agentsignup',
  templateUrl: './agentsignup.component.html',
  styleUrls: ['./agentsignup.component.css']
})
export class AgentsignupComponent implements OnInit {

  constructor(private appService: AppService, private router: Router) { }

  ngOnInit() {
  }

  agentSignup(object) {
    if (object.password == object.confirmpassword) {
      this.appService.agentSignup(object).subscribe((data: String) => {
        console.log("result", data);
      });
      this.router.navigate(['/agentLogin']);

      console.log("login success");
    }
    else{
      console.log("pass mismatch......");
    }
  }
}
