import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-demand-draft',
  templateUrl: './demand-draft.component.html',
  styleUrls: ['./demand-draft.component.css']
})
export class DemandDraftComponent implements OnInit {

  ddNumber: Number;
  obj:Object;
  agentId: Number;
  date = new Date();
  constructor(private router:Router,private appService:AppService) { }

  ngOnInit() {
    this.agentId = +sessionStorage.getItem('agentId');
    if(!this.agentId){
      this.router.navigate(['/agentLogin']);
    }
  }

  createDD(object){
    console.log("dd",object);
    this.obj = {
      accountNumber: object.accountNumber,
      name: object.name,
      city: object.city,
      amount: object.amount,
      amountInWords: object.amountInWords
    }
    
    this.appService.createDD(object).subscribe((data)=>{
      console .log(data);
      this.router.navigate(['/ddConfirm']);
    })
   
    
  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['/agentLogin']);
  }

}
