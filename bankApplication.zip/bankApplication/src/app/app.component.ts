import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'bankApplication';
  time: any;
  agentId: String;
  currentUserId: String;
  show: String;
  username: String;

  
  constructor(private router: Router) { }

  ngOnInit() {
    setInterval(() => {
      this.currentUserId = sessionStorage.getItem('currentId');
      this.username = sessionStorage.getItem('username');
      this.show = sessionStorage.getItem('currentId');
      if(!this.show){
      this.show = sessionStorage.getItem('agentId');
      this.agentId = sessionStorage.getItem('agentId');
      }
      this.time = new Date();
    }, 100);
  }


}

