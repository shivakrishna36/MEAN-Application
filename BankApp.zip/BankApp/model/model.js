const dbconnect = require('../db/db');

function agentSignup(agentObject) {
    let sql = `INSERT INTO agents (agentName, agentPassword) VALUES ('${agentObject.userName}','${agentObject.password}' )`;
    dbconnect.query(sql, (err, result) => {
        if (err)
            console.log("error", err);
        else
            console.log("inserted", result);
        return "OK";
    })
}


async function agentLogin(agentId) {
    let sql = `select * from agents WHERE agentId=${agentId}`;
    return new Promise(function (resolve, reject) {
        dbconnect.query(sql, (err, result) => {
            if (err) reject(err);
            else {
                resolve(result);
            }
        })
    })


}

function customerSignupBYAgent(customerObject) {
    let sql = `INSERT INTO customers 
    (firstName, lastName, fatherName, motherName, age, gender, mobileNumber, amount, address, dateOfBirth, type)
    values(
    '${customerObject.firstName}',
    '${customerObject.lastName}',
    '${customerObject.fatherName}',
    '${customerObject.motherName}',
    '${customerObject.age}',
    '${customerObject.gender}',
    '${customerObject.mobileNumber}',
    '${customerObject.amount}',
    '${customerObject.address}',
    '${customerObject.dob}',
    '${customerObject.type}'
    )`;
    return new Promise(function (resolve, reject) {

        dbconnect.query(sql, (err, result) => {
            if (err)
                reject(err);
            resolve(result);

        })
    })
}

function customerAccountSignup(obj) {
    console.log("object", obj);
    let query = `SELECT * from customers WHERE accountNumber = ${obj.accountNumber}`;
    return new Promise(function (resolve, reject) {
        dbconnect.query(query, (err, result) => {
            if (err)
                reject(err);
            else {
                resolve(console.log("result", result))
                if (obj.firstName == result[0].firstName && obj.lastName == result[0].lastName) {
                    let sql = `INSERT INTO customerAccount (firstName, lastName, accountNumber, password)
                                values (
                                        '${obj.firstName}', 
                                        '${obj.lastName}',
                                        '${obj.accountNumber}',
                                        '${obj.password}'
                                        )`;
                    dbconnect.query(sql, (err, result) => {
                        if (err) reject(err);
                        else
                            resolve(result);
                    })
                }


            }
        })
    })



}

function customerLogin(obj) {
    console.log("id", obj);
    let sql = `SELECT * FROM customerAccount WHERE accountNumber=${obj.accountNumber}`;
    return new Promise((resolve, reject) => {
        dbconnect.query(sql, (err, result) => {
            if (err) reject(err);
            else {
                resolve(result);
            }
        })
    })

}

function getAccountDetails() {
    let sql = "SELECT * FROM customers";
    return new Promise(function (resolve, reject) {

        dbconnect.query(sql, (err, result) => {
            if (err)
                reject(err);
            resolve(result);

        })
    })
}

function getBalance(id) {
    let sql = `SELECT amount from customers WHERE accountNumber=${id}`;
    return new Promise(function (resolve, reject) {

        dbconnect.query(sql, (err, result) => {
            if (err)
                reject(err);
            console.log(result);
            resolve(result);

        })
    })
}

function getAccountById(id) {
    let sql = `SELECT * from customers WHERE accountNumber=${id}`;
    return new Promise(function (resolve, reject) {

        dbconnect.query(sql, (err, result) => {
            if (err)
                reject(err);
            console.log(result);
            resolve(result);

        })
    })
}

async function updateCustomer(object) {
    let obj = await getBalance(object.accountNumber);
    let amount = object.amount;
    console.log(typeof (obj[0].amount), typeof (object.amount));

    if (object.type == 'debit') {
        object.amount = -object.amount;
    }
    console.log("addd", typeof (obj[0].amount) + typeof (object.amount));
    let sql = `UPDATE customers SET amount = ${obj[0].amount + object.amount} WHERE accountNumber=${object.accountNumber}`;
    return new Promise(function (resolve, reject) {

        dbconnect.query(sql, (err, result) => {
            if (err)
                reject(err);
            else
                //console.log(result);
                resolve(result);
        })
    }).then(async (result) => {
        console.log("result[0]", result);
        let total = await getBalance(object.accountNumber);
        let sql = `Insert INTO transactions( type, amount, accountNumber, total)
        values ('${object.type}','${amount}','${object.accountNumber}','${total[0].amount}')`;
        return new Promise(function (resolve, reject) {
            dbconnect.query(sql, (err, result) => {
                if (err)
                    reject(err);
                console.log(result);
                resolve(result);
            })
        })
    })
}

function getTransactons() {
    let sql = "SELECT * FROM transactions";
    return new Promise(function (resolve, reject) {

        dbconnect.query(sql, (err, result) => {
            if (err)
                reject(err);
            resolve(result);

        })
    })
}

function getTransactionsById(id) {
    let sql = `SELECT * from transactions WHERE accountNumber=${id}`;
    return new Promise(function (resolve, reject) {

        dbconnect.query(sql, (err, result) => {
            if (err)
                reject(err);
            console.log(result);
            resolve(result);

        })
    })
}


function createDD(obj) {
    let sql = `INSERT INTO dd(accountNumber, name, amount, amountInWords, city)
    values('${obj.accountNumber}','${obj.name}','${obj.amount}','${obj.amountInWords}','${obj.city}')`;
    return new Promise(function (resolve, reject) {

        dbconnect.query(sql, (err, result) => {
            if (err)
                reject(err);
            console.log(result);
            resolve(result);

        })
    })



}

function getDD() {
    return new Promise(function (resolve, reject) {
        dbconnect.query('select *from dd ORDER BY ddno DESC LIMIT 1', (err, result) => {
            if (err)
                reject(err);
            console.log(result);
            resolve(result);

        })
    })
}

function getMobileBankingAccount(id) {
    return new Promise(function (resolve, reject) {
        dbconnect.query(`select * from customerAccount WHERE accountNumber = ${id}`, (err, result) => {
            if (err)
                reject(err);
            console.log(result);
            resolve(result);

        })
    })
}

async function createCustomerTransaction(obj) {

    return new Promise(async function (resolve, reject) {
        let sender = await getAccountById(obj.senderAccountNumber);
        dbconnect.query(`UPDATE customers SET amount = ${sender[0].amount - obj.amount} WHERE accountNumber=${obj.senderAccountNumber}`, (err, result) => {
            if (err)
                reject(err);
            console.log(result);
            resolve(result);
        })
    }).then(async() => {
        return new Promise(async function (resolve, reject) {
            let receiver = await getAccountById(obj.receiverAccountNumber);
            dbconnect.query(`UPDATE customers SET amount = ${receiver[0].amount + obj.amount} WHERE accountNumber=${obj.receiverAccountNumber}`, (err, result) => {
                if (err)
                    reject(err);
                console.log(result);
                resolve(result);
            })
        })
    }).then(() => {

        return new Promise(function (resolve, reject) {
            dbconnect.query(`INSERT INTO customerTransactions(type, amount, senderAccountNumber,receiverAccountNumber)
            values ('${obj.type}','${obj.amount}','${obj.senderAccountNumber}','${obj.receiverAccountNumber}')`, (err, result) => {
                if (err)
                    reject(err);
                console.log(result);
                resolve(result);

            })
        })
    }).catch((err)=>{
        console.log("error",err);
    })




}

function getStatements(id) {
    return new Promise(function (resolve, reject) {
        dbconnect.query(`Select * from customerTransactions WHERE senderAccountNumber = ${id}`, (err, result) => {
            if (err)
                reject(err);
            console.log(result);
            resolve(result);

        })
    })
}

module.exports = {
    agentSignup,
    agentLogin,
    customerSignupBYAgent,
    customerAccountSignup,
    customerLogin,
    getAccountDetails,
    getBalance,
    getAccountById,
    updateCustomer,
    getTransactons,
    getTransactionsById,
    createDD,
    getDD,
    getMobileBankingAccount,
    createCustomerTransaction,
    getStatements
};