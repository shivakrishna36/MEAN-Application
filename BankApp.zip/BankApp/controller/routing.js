var express = require('express');
const router = express.Router();
var cors = require('cors');
const model = require('../model/model');
router.use(cors());

router.get('/', (req, res) => {

    res.end("Welcome");
})

router.post('/agentSignup', (req, res) => {
    console.log(req.body);
    model.agentSignup(req.body);
    res.send("ok")
})

router.get('/agentLogin/:loginId', (req, res) => {
    console.log("agentlogin", req.params.loginId);
    let id = req.params.loginId;
    model.agentLogin(id).then((data) => {
        res.send(data[0]);
    });


})

router.post('/customerSignupByAgent', (req, res) => {
    //console.log("customer login",req.body);
    let customerObject = req.body;
    model.customerSignupBYAgent(customerObject).then((data) => {
        res.send(data[0]);
    });
})

router.post('/customerAccountSignup', (req, res) => {
    model.customerAccountSignup(req.body).then((data) => {
        console.log("jaffdata", data);
        res.send();
    });
})

router.get('/customerLogin/:agentId', (req, res) => {
    let obj = {
        accountNumber: req.params.agentId,

    }
    model.customerLogin(obj).then((data) => {
        res.send(data[0]);
    });

})

router.get('/accountDetails', (req, res) => {
    model.getAccountDetails().then((data) => {
        res.send(data);
    })
})

router.get('/getBalance/:id',(req,res)=>{
    console.log("req.params.id",req.params.id);
    model.getBalance(req.params.id).then((data)=>{
        res.send(data[0]);
    })
})

router.get('/accountDetails/:id',(req,res)=>{
    console.log("req.params.id",req.params.id);
    model.getAccountById(req.params.id).then((data)=>{
        res.send(data[0]);
    })
})

router.post('/update',(req,res)=>{
    console.log("update",req.body);
    model.updateCustomer(req.body).then((data)=>{
        res.send(data[0]);
    })
})

router.get('/getTransactions',(req,res)=>{
    model.getTransactons().then((data)=>{
        res.send(data);
    })
})

router.get('/getTransactions/:id',(req,res)=>{
    let id = req.params.id;
    model.getTransactionsById(id).then((data)=>{
        res.send(data);
    })
})

router.post('/dd',(req,res)=>{
    console.log("req.body",req.body);
    model.createDD(req.body).then((data)=>{
        res.send(data);
    })
})

router.get('/dd',(req,res)=>{
    model.getDD().then((data)=>{
        res.send(data);
    })
})

router.get('/accountById/:id',(req,res)=>{
    model.getMobileBankingAccount(req.params.id).then((data)=>{
        res.send(data[0]);
    })
})

router.post('/customerTransaction',(req,res)=>{
    model.createCustomerTransaction(req.body).then((data)=>{
        res.send(data[0]);
    })
})

router.get('/getStatements/:id',(req,res)=>{
    model.getStatements(req.params.id).then((data)=>{
        res.send(data);
    })
})
module.exports = router;