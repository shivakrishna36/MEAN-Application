var express = require('express');
var app = express();
const bodyparser = require('body-parser');

const router = require('./controller/routing');

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: true }));
app.use('/',router);


app.listen(4444, () => console.log('Running on port 4444'));